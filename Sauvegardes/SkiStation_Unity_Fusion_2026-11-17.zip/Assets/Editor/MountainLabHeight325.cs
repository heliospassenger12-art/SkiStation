using System;
using UnityEngine;

namespace SkiStation.MountainLab.Editor
{
    [Serializable]
    public sealed class MountainLabSettings325
    {
        public int seed = 325;
        public float heightScale = 1f;
        public float naturalVariation = .72f;
        public int resolution = 257;
        public bool trees = true;
        public bool slopeColours;
    }

    // 3.24: natural micro-relief across the full 360-degree map: subtle rolls, hollows, convexities and local breaks.
    // Editor-only: broad skiable/buildable areas remain readable; micro-relief avoids the procedural smooth-sheet look.
    // Editor-only: deliberately isolated from the management terrain until the player validates the shape.
    public sealed class MountainLabHeight325
    {
        public const float Width = 6000f, Length = 8200f;
        public const float MinX = -3000f, MinZ = -2800f, FlatEnd = -1500f, BaseY = 1600f;
        readonly FastNoiseLite broad, detail, ridge, warp;
        readonly float scale, variation;

        public MountainLabHeight325(MountainLabSettings325 settings)
        {
            scale = Mathf.Clamp(settings.heightScale, .7f, 1.25f);
            variation = Mathf.Clamp01(settings.naturalVariation);
            broad = Noise(settings.seed, .00105f, 4, FastNoiseLite.FractalType.FBm);
            detail = Noise(unchecked(settings.seed + 11), .0042f, 2, FastNoiseLite.FractalType.FBm);
            ridge = Noise(unchecked(settings.seed + 29), .0024f, 3, FastNoiseLite.FractalType.Ridged);
            warp = new FastNoiseLite(unchecked(settings.seed + 47));
            warp.SetFrequency(.0009f); warp.SetDomainWarpAmp(135f * variation);
            warp.SetDomainWarpType(FastNoiseLite.DomainWarpType.OpenSimplex2);
        }

        static FastNoiseLite Noise(int seed, float frequency, int octaves, FastNoiseLite.FractalType type)
        {
            var n = new FastNoiseLite(seed); n.SetNoiseType(FastNoiseLite.NoiseType.OpenSimplex2);
            n.SetFrequency(frequency); n.SetFractalType(type); n.SetFractalOctaves(octaves); n.SetFractalGain(.46f); return n;
        }

        public float Height(float x, float z)
        {
            x = Mathf.Clamp(x, MinX, -MinX); z = Mathf.Clamp(z, MinZ, MinZ + Length);
            if (z <= FlatEnd) return BaseY;
            float wx=x,wz=z; warp.DomainWarp(ref wx, ref wz);

            // 1600 -> ~4200 m: long progressive climb so the vertical range does not become one giant wall.
            float frontU = Mathf.Clamp01((z - FlatEnd) / 5000f);
            float climb = 1850f * Mathf.Pow(frontU, 1.12f);
            float high = Blend(z, 1750f, 3350f);
            float glacier = 200f * high;

            // Large readable terrain families: low resort, family shoulder, central valley and alpine side.
            float lowPlateau = -150f * Gaussian(z, -450f, 760f);
            float westShoulder = 150f * Gaussian(x, -1750f, 900f) * Blend(z, -1100f, 1550f);
            float centralValley = -185f * Gaussian(x, -180f, 820f) * Blend(z, -900f, 2250f);
            float eastShoulder = 230f * Gaussian(x, 1700f, 820f) * Blend(z, -650f, 2650f);
            float familySector = -75f * Gaussian(x, -1350f, 760f) * Gaussian(z, 350f, 1150f);
            float alpineBowl = -155f * Gaussian(x, 620f, 1050f) * Gaussian(z, 2350f, 950f);

            // Natural ski corridors and a broad saddle through the upper massif.
            float corridorA = -72f * Gaussian(x + 1450f + .16f*(z+250f), 0f, 300f) * Blend(z,-1150f,2200f);
            float corridorB = -65f * Gaussian(x - 850f - .08f*(z+100f), 0f, 340f) * Blend(z,-1000f,2600f);
            float saddle = -120f * Gaussian(x, 120f, 520f) * Gaussian(z, 3250f, 650f);

            float noiseFade = Blend(z, -1300f, -450f) * (1f - .35f*Blend(z,3900f,5200f));
            float rolls = (68f*broad.GetNoise(wx,wz) + 13f*detail.GetNoise(x,z))*variation*noiseFade;

            // High alpine/glacial crown: wide snowfields separated by rocky crests rather than one needle peak.
            float summitMask = Blend(z, 2550f, 3450f) * (1f - .35f*Blend(z,4300f,5350f));
            float summit = summitMask * (150f + 120f*ridge.GetNoise(wx,wz));
            float crest = 90f * summitMask * Mathf.Abs(Mathf.Sin((x + .22f*z) * .0022f));
            float glacierBasin = -115f * Gaussian(x, -450f, 1250f) * Gaussian(z, 3850f, 900f);

            // 3.24 — glacier architecture: long flowing ice tongues, cirques and rocky ribs.
            // Keep the glacier broadly skiable; steep visual drama lives mainly on its edges and crests.
            float iceZone = Blend(z, 2850f, 3650f);
            float glacierTongueA = -125f * Gaussian(x + 520f + .11f*(z-3300f), 0f, 720f) * Gaussian(z, 3900f, 1250f) * iceZone;
            float glacierTongueB = -92f * Gaussian(x - 1280f - .06f*(z-3600f), 0f, 560f) * Gaussian(z, 4100f, 1100f) * iceZone;
            float highCirque = -155f * Gaussian(x, 520f, 1050f) * Gaussian(z, 4300f, 720f);
            float rockyRibWest = 185f * Gaussian(x, -2150f, 330f) * Gaussian(z, 3600f, 1050f) * iceZone;
            float rockyRibEast = 210f * Gaussian(x, 2250f, 300f) * Gaussian(z, 3850f, 980f) * iceZone;
            float summitNeedleA = 245f * Gaussian(x, -1500f, 420f) * Gaussian(z, 4200f, 520f);
            float summitNeedleB = 280f * Gaussian(x, 1550f, 390f) * Gaussian(z, 4450f, 500f);
            // Soft transverse waves suggest glacier flow without creating impassable steps.
            float glacierFlow = iceZone * 24f * Mathf.Sin((z + .18f*x) * .0042f) * (0.55f + .45f*Gaussian(x, 250f, 1900f));

            // 3.24 — natural altitude balconies: broad, gently undulating benches rather than artificial flat platforms.
            // They create believable buildable/activity areas for refuges, restaurants, sled dogs and paragliding.
            float balconyLow = -105f * Gaussian(z, 250f, 430f) * Gaussian(x, -1050f, 1450f);      // ~2000-2400 m wooded balcony
            float balconyMid = -145f * Gaussian(z, 1450f, 520f) * Gaussian(x, 850f, 1650f);       // ~2500-3000 m activity plateau
            float balconyPanorama = -175f * Gaussian(z, 2550f, 500f) * Gaussian(x, -650f, 1550f); // ~3000-3500 m panoramic terrace
            float glacierShelf = -135f * Gaussian(z, 3650f, 560f) * Gaussian(x, 700f, 1750f);     // high gentle glacier shelf

            // Soft local undulation keeps every balcony natural and prevents perfectly horizontal shelves.
            float balconyMask = Mathf.Clamp01(
                Gaussian(z, 250f, 650f) + Gaussian(z, 1450f, 720f) + Gaussian(z, 2550f, 680f) + Gaussian(z, 3650f, 720f));
            float balconyRolls = balconyMask * variation * (18f * broad.GetNoise(wx + 420f, wz - 310f) + 6f * detail.GetNoise(x, z));

            // Small raised lips around selected benches make the transitions read as natural shoulders/terraces.
            float terraceLipA = 42f * Gaussian(z, 760f, 260f) * Gaussian(x, -1250f, 1700f);
            float terraceLipB = 55f * Gaussian(z, 2020f, 300f) * Gaussian(x, 650f, 1750f);
            float terraceLipC = 48f * Gaussian(z, 3250f, 290f) * Gaussian(x, -450f, 1850f);

            // 3.24 — identités de versants sur toute la carte, pensées en volume 360° et jamais comme des façades.
            // Ouest : relief plus doux/boisé ; est : secteur minéral/freeride ; centre : grands espaces alpins ouverts.
            float westFamilyRelief = -62f * Gaussian(x, -2050f, 760f) * Gaussian(z, 1150f, 1700f);
            float westShelteredShoulder = 72f * Gaussian(x, -2450f, 520f) * Gaussian(z, 2050f, 1450f);
            float centralOpenBowl = -92f * Gaussian(x, 80f, 1150f) * Gaussian(z, 1550f, 1750f);
            float eastFreerideFace = 165f * Gaussian(x, 2200f, 520f) * Gaussian(z, 2200f, 1550f)
                * (0.62f + 0.38f * Mathf.Abs(Mathf.Sin((x - .35f*z) * .0056f)));
            float eastRockCouloir = -88f * Gaussian(x - 2050f + .12f*(z-1900f), 0f, 260f) * Gaussian(z, 2450f, 1250f);
            // La face arrière possède elle aussi plusieurs caractères afin que le 360° s'applique réellement à toute la map.
            float rearWestBowlIdentity = -105f * Gaussian(x, -1650f, 820f) * Gaussian(z, 4850f, 720f);
            float rearEastRockIdentity = 125f * Gaussian(x, 1850f, 600f) * Gaussian(z, 4750f, 760f)
                * (0.68f + 0.32f * Mathf.Abs(Mathf.Sin((x + .28f*z) * .0052f)));

            // 3.24 — connected high-mountain geography: passes and hanging valleys make the crown traversable.
            // These are terrain forms, not pistes: the player remains free to choose the actual ski-domain layout.
            float glacierPassWest = -105f * Gaussian(x, -1050f, 430f) * Gaussian(z, 3500f, 520f) * iceZone;
            float glacierPassEast = -95f * Gaussian(x, 1180f, 420f) * Gaussian(z, 3820f, 500f) * iceZone;
            float hangingValleyWest = -115f * Gaussian(x, -1650f, 650f) * Gaussian(z, 2850f, 780f);
            float hangingValleyEast = -125f * Gaussian(x, 1550f, 700f) * Gaussian(z, 3000f, 820f);
            float panoramicSpur = 92f * Gaussian(x, -450f, 720f) * Gaussian(z, 2050f, 620f);
            float glacierDome = 135f * Gaussian(x, 250f, 980f) * Gaussian(z, 4680f, 700f) * iceZone;

            // 3.24 — summit diversity: a serrated mineral crown, rounded glacial domes and broad skiable cols.
            // The contrast avoids a repeated ridge silhouette while keeping several natural crossings.
            float mineralCrownWest = 250f * Gaussian(x, -2350f, 360f) * Gaussian(z, 4350f, 620f) * (0.72f + 0.28f*Mathf.Abs(Mathf.Sin((x + .31f*z)*.0062f)));
            float mineralCrownEast = 285f * Gaussian(x, 2380f, 340f) * Gaussian(z, 4520f, 650f) * (0.70f + 0.30f*Mathf.Abs(Mathf.Sin((x - .27f*z)*.0068f)));
            float centralRockTower = 205f * Gaussian(x, 720f, 360f) * Gaussian(z, 4920f, 430f);
            float roundedGlacialDomeWest = 105f * Gaussian(x, -780f, 900f) * Gaussian(z, 4750f, 760f);
            float roundedGlacialDomeEast = 90f * Gaussian(x, 1450f, 820f) * Gaussian(z, 4250f, 720f);
            float broadColWest = -125f * Gaussian(x, -1550f, 520f) * Gaussian(z, 4380f, 470f);
            float broadColCentral = -145f * Gaussian(x, 120f, 600f) * Gaussian(z, 4550f, 500f);
            float broadColEast = -118f * Gaussian(x, 1620f, 500f) * Gaussian(z, 4460f, 480f);
            float summitSerrationMask = Blend(z, 3600f, 4300f) * (1f - Blend(z, 5050f, 5350f));
            float summitSerration = summitSerrationMask * 58f * Mathf.Abs(Mathf.Sin((x + .42f*z) * .0049f)) * (0.45f + 0.55f*Gaussian(x, 0f, 2700f));

            // 3.24 — grands vallons intermédiaires : relient visuellement et topographiquement le village aux étages alpins.
            // Ils ne tracent aucune piste : ce sont de larges formes naturelles qui laissent plusieurs choix au joueur.
            float lowerWestValley = -92f * Gaussian(x, -1550f, 620f) * Gaussian(z, 650f, 1050f);
            float lowerEastValley = -78f * Gaussian(x, 1450f, 700f) * Gaussian(z, 900f, 1150f);
            float middleWestValley = -128f * Gaussian(x, -900f, 720f) * Gaussian(z, 1850f, 1050f);
            float middleEastValley = -112f * Gaussian(x, 1250f, 760f) * Gaussian(z, 2100f, 1100f);
            float alpineConnector = -118f * Gaussian(x, 180f, 850f) * Gaussian(z, 2850f, 980f);
            // Épaules entre vallons : elles évitent une succession de cuvettes molles et créent des changements de paysage.
            float valleyShoulderWest = 72f * Gaussian(x, -2350f, 520f) * Gaussian(z, 1450f, 1450f);
            float valleyShoulderEast = 86f * Gaussian(x, 2350f, 500f) * Gaussian(z, 1700f, 1500f);
            float middleSpine = 58f * Gaussian(x, 380f, 520f) * Gaussian(z, 1500f, 1150f);
            // Une ondulation très large casse les longues pentes uniformes sans créer de marches artificielles.
            float valleyWaveMask = Blend(z, -850f, 450f) * (1f - Blend(z, 3100f, 3700f));
            float valleyWaves = valleyWaveMask * variation * (30f * Mathf.Sin((x + .20f*z) * .00155f) + 14f * broad.GetNoise(wx-760f,wz+540f));

            // 3.24 — densification 360° : combes secondaires, cols locaux et vallons latéraux sur TOUT le massif.
            // Les formes sont larges et entrecroisées : elles multiplient les choix sans dessiner de pistes à la place du joueur.
            float sideBowlNW = -82f * Gaussian(x, -2380f, 470f) * Gaussian(z, 350f, 720f);
            float sideBowlSW = -68f * Gaussian(x, -2050f, 520f) * Gaussian(z, 2150f, 760f);
            float sideBowlNE = -88f * Gaussian(x, 2260f, 500f) * Gaussian(z, 650f, 760f);
            float sideBowlSE = -96f * Gaussian(x, 2050f, 540f) * Gaussian(z, 2850f, 760f);
            float rearBowlWest2 = -92f * Gaussian(x, -2250f, 560f) * Gaussian(z, 4550f, 620f);
            float rearBowlEast2 = -84f * Gaussian(x, 2250f, 560f) * Gaussian(z, 5000f, 600f);

            // Petits cols de liaison : passages naturels entre épaules, y compris vers la face arrière.
            float localPassW1 = -72f * Gaussian(x, -2050f, 330f) * Gaussian(z, 1200f, 360f);
            float localPassW2 = -86f * Gaussian(x, -1450f, 350f) * Gaussian(z, 3150f, 390f);
            float localPassE1 = -75f * Gaussian(x, 1950f, 340f) * Gaussian(z, 1450f, 380f);
            float localPassE2 = -90f * Gaussian(x, 1450f, 360f) * Gaussian(z, 3350f, 400f);
            float rearPassW = -82f * Gaussian(x, -1150f, 380f) * Gaussian(z, 4750f, 390f);
            float rearPassE = -78f * Gaussian(x, 1150f, 380f) * Gaussian(z, 4920f, 390f);

            // Vallons obliques : cassent la lecture avant/arrière et rendent les côtés réellement exploitables.
            float lateralValleyW = -78f * Gaussian(x + 2250f - .23f*(z-1600f), 0f, 300f) * Gaussian(z, 1800f, 1450f);
            float lateralValleyE = -82f * Gaussian(x - 2250f + .21f*(z-1850f), 0f, 310f) * Gaussian(z, 2050f, 1500f);
            float rearTraverseW = -70f * Gaussian(x + 1550f + .18f*(z-4550f), 0f, 340f) * Gaussian(z, 4700f, 760f);
            float rearTraverseE = -72f * Gaussian(x - 1600f - .17f*(z-4650f), 0f, 340f) * Gaussian(z, 4780f, 760f);

            // Contreforts positifs entre les creux : le massif garde du volume et ne devient pas une succession de cuvettes.
            float buttressW = 68f * Gaussian(x, -2700f, 300f) * Gaussian(z, 2600f, 1550f);
            float buttressE = 74f * Gaussian(x, 2700f, 300f) * Gaussian(z, 2750f, 1550f);
            float rearButtress = 62f * Gaussian(x, 0f, 520f) * Gaussian(z, 5100f, 500f);

            // 3.24 — finition géologique 360° : barres rocheuses, ruptures de pente et éperons.
            // Le relief spectaculaire reste concentré sur les bordures/épaules afin de préserver de grandes surfaces skiables.
            float geologyMask = Blend(z, 250f, 1450f) * (1f - .22f * Blend(z, 4850f, 5350f));
            float rockBandsWest = 92f * geologyMask * Gaussian(x, -2520f, 360f) * (0.35f + 0.65f*Mathf.Abs(Mathf.Sin((z + .20f*x)*.0064f)));
            float rockBandsEast = 108f * geologyMask * Gaussian(x, 2520f, 340f) * (0.32f + 0.68f*Mathf.Abs(Mathf.Sin((z - .18f*x)*.0068f)));
            float centralRockBar = 72f * Gaussian(x, 520f, 540f) * Gaussian(z, 2350f, 520f) * Mathf.Abs(Mathf.Sin((x + .38f*z)*.0072f));
            float westRockBar = 88f * Gaussian(x, -1750f, 480f) * Gaussian(z, 2700f, 560f) * Mathf.Abs(Mathf.Sin((x - .24f*z)*.0075f));
            float rearRockBar = 96f * Gaussian(x, 1350f, 520f) * Gaussian(z, 4720f, 500f) * Mathf.Abs(Mathf.Sin((x + .31f*z)*.0071f));

            // Ruptures de pente larges : donnent des étages naturels sans créer de murs continus.
            float breakLow = 42f * Gaussian(z, 980f, 230f) * (0.45f + 0.55f*Gaussian(x, -300f, 2500f));
            float breakMid = 58f * Gaussian(z, 2450f, 250f) * (0.42f + 0.58f*Gaussian(x, 450f, 2350f));
            float breakHigh = 66f * Gaussian(z, 3520f, 240f) * (0.40f + 0.60f*Gaussian(x, -250f, 2200f));

            // Éperons rocheux isolés et couloirs entre eux : identité alpine sans condamner le passage.
            float spurNW = 118f * Gaussian(x, -2680f, 260f) * Gaussian(z, 1850f, 620f);
            float spurNE = 132f * Gaussian(x, 2680f, 250f) * Gaussian(z, 2050f, 650f);
            float spurRearW = 105f * Gaussian(x, -2500f, 280f) * Gaussian(z, 4550f, 520f);
            float spurRearE = 120f * Gaussian(x, 2520f, 270f) * Gaussian(z, 4680f, 540f);
            float geologyCouloirW = -62f * Gaussian(x + 2200f - .10f*(z-2500f), 0f, 240f) * Gaussian(z, 2850f, 900f);
            float geologyCouloirE = -66f * Gaussian(x - 2200f + .11f*(z-2600f), 0f, 245f) * Gaussian(z, 2950f, 920f);

            // 3.24 — micro-relief naturel 360° : petites bosses, creux et ondulations à plusieurs échelles.
            // L'amplitude reste volontairement faible : on enrichit la lecture du terrain sans fabriquer des pistes ni des obstacles artificiels.
            float microMask = Blend(z, -1250f, -350f) * (1f - .30f * Blend(z, 4100f, 5250f));
            float microBroad = microMask * variation * (16f * broad.GetNoise(wx + 1730f, wz - 940f));
            float microDetail = microMask * variation * (7f * detail.GetNoise(x * .82f - 510f, z * .82f + 690f));
            // Ondulations très larges, orientées différemment selon la carte : aucune lecture en façade avant/arrière.
            float crossRolls = microMask * variation * 13f * Mathf.Sin((x - .31f*z) * .00235f) * Mathf.Sin((z + .17f*x) * .00185f);
            // Quelques creux/convexités locaux, distribués sur les quatre quadrants et la face arrière.
            float hollowNW = -24f * Gaussian(x, -1850f, 520f) * Gaussian(z, 650f, 620f);
            float bumpNE = 21f * Gaussian(x, 1900f, 480f) * Gaussian(z, 1050f, 590f);
            float hollowSE = -22f * Gaussian(x, 1750f, 560f) * Gaussian(z, 3050f, 650f);
            float bumpSW = 19f * Gaussian(x, -1950f, 500f) * Gaussian(z, 2550f, 620f);
            float rearHollow = -20f * Gaussian(x, -850f, 620f) * Gaussian(z, 4650f, 520f);
            float rearBump = 18f * Gaussian(x, 1250f, 560f) * Gaussian(z, 4850f, 500f);
            // Petites ruptures locales et non continues : sensation de terrain naturel sans créer d'escalier.
            float localBreaks = microMask * 11f * Mathf.Abs(Mathf.Sin((x + .47f*z) * .0041f))
                * (0.35f + 0.65f * Mathf.Abs(broad.GetNoise(wx - 1220f, wz + 880f)));

            // 3.24 — intégration fine des crêtes et falaises, toujours en 360°.
            // Petites lèvres rocheuses et tabliers d’éboulis : elles soulignent les ruptures existantes
            // sans former de mur continu ni condamner les grandes combes skiables.
            float cliffMask = Blend(z, 500f, 1800f) * (1f - .18f * Blend(z, 4700f, 5350f));
            float cliffWest = 38f * cliffMask * Gaussian(x, -2460f, 260f) * Mathf.Pow(Mathf.Abs(Mathf.Sin((z + .17f*x) * .0082f)), 3f);
            float cliffEast = 44f * cliffMask * Gaussian(x, 2440f, 250f) * Mathf.Pow(Mathf.Abs(Mathf.Sin((z - .15f*x) * .0085f)), 3f);
            float cliffRearW = 36f * Gaussian(x, -2050f, 330f) * Gaussian(z, 4620f, 720f) * Mathf.Pow(Mathf.Abs(Mathf.Sin((x + .28f*z) * .0077f)), 3f);
            float cliffRearE = 40f * Gaussian(x, 2100f, 320f) * Gaussian(z, 4720f, 720f) * Mathf.Pow(Mathf.Abs(Mathf.Sin((x - .25f*z) * .0079f)), 3f);
            float screeWest = -18f * Gaussian(x, -2250f, 520f) * Gaussian(z, 3000f, 1250f);
            float screeEast = -20f * Gaussian(x, 2260f, 500f) * Gaussian(z, 3150f, 1280f);
            float crestChips = 22f * Blend(z, 2550f, 3500f) * variation
                * Mathf.Abs(ridge.GetNoise(wx + 2120f, wz - 1760f))
                * (Gaussian(x, -1550f, 720f) + Gaussian(x, 1650f, 720f));

            // 3.25 — glaciers structurés sur l'ensemble de la haute montagne, toujours lisibles en 360°.
            // De grands champs de glace restent doux et skiables ; les ruptures et moraines sont repoussées vers leurs bordures.
            float glacierCore = Blend(z, 3000f, 3720f) * (1f - .20f * Blend(z, 5000f, 5400f));
            float iceFieldWest = -58f * glacierCore * Gaussian(x, -820f, 980f) * Gaussian(z, 4100f, 1120f);
            float iceFieldEast = -52f * glacierCore * Gaussian(x, 980f, 1050f) * Gaussian(z, 4250f, 1080f);
            // Langues secondaires orientées différemment : elles donnent une vraie lecture d'écoulement et évitent un glacier en simple nappe.
            float iceTongueWest = -48f * glacierCore * Gaussian(x + 980f + .16f*(z-3900f), 0f, 430f) * Gaussian(z, 4050f, 1180f);
            float iceTongueEast = -44f * glacierCore * Gaussian(x - 1120f - .13f*(z-4050f), 0f, 450f) * Gaussian(z, 4200f, 1150f);
            // Ruptures glaciaires larges et peu profondes : sensation de séracs/gradins sans créer de marches infranchissables.
            float iceBreakMask = glacierCore * (Gaussian(x, -620f, 1500f) + Gaussian(x, 900f, 1500f));
            float iceBreaks = 15f * iceBreakMask * Mathf.Pow(Mathf.Abs(Mathf.Sin((z + .12f*x) * .0061f)), 4f);
            // Ondulations longitudinales très douces, compatibles avec de longues pistes bleues sur glacier.
            float iceFlowLines = 9f * glacierCore * variation * Mathf.Sin((x - .10f*z) * .0034f)
                * (0.55f + 0.45f*Mathf.Abs(broad.GetNoise(wx + 760f, wz - 430f)));
            // Moraines latérales et bordures rocheuses : soulignent la glace sans couper le cœur skiable.
            float moraineWest = 34f * glacierCore * Gaussian(x, -2050f, 230f) * Gaussian(z, 4050f, 1150f);
            float moraineEast = 38f * glacierCore * Gaussian(x, 2100f, 240f) * Gaussian(z, 4200f, 1120f);
            float glacierRearShelf = -42f * Gaussian(x, -250f, 1450f) * Gaussian(z, 4930f, 500f);

            // Rear face remains usable: the main crown drops toward a second high valley behind the watershed.
            float rear = Blend(z, 4050f, 5400f);
            float rearDrop = -rear * 820f;
            float rearBowl = -150f * Gaussian(x, -650f, 1050f) * Gaussian(z, 4850f, 800f) * rear;
            float rearFamily = -70f * Gaussian(x, -1900f, 720f) * Gaussian(z, 4700f, 900f) * rear;
            float rearSpur = 150f * Gaussian(x, 1650f, 620f) * Gaussian(z, 4550f, 800f) * rear;
            float rearRolls = rear * variation * (42f*broad.GetNoise(wx+900f,wz-1200f) + 10f*detail.GetNoise(x,z));

            return BaseY + scale * Mathf.Max(0f, climb + glacier + lowPlateau + westShoulder + centralValley + eastShoulder + familySector + alpineBowl + corridorA + corridorB + saddle + rolls + summit + crest + glacierBasin + glacierTongueA + glacierTongueB + highCirque + rockyRibWest + rockyRibEast + summitNeedleA + summitNeedleB + glacierFlow + balconyLow + balconyMid + balconyPanorama + glacierShelf + balconyRolls + terraceLipA + terraceLipB + terraceLipC + westFamilyRelief + westShelteredShoulder + centralOpenBowl + eastFreerideFace + eastRockCouloir + rearWestBowlIdentity + rearEastRockIdentity + glacierPassWest + glacierPassEast + hangingValleyWest + hangingValleyEast + panoramicSpur + glacierDome + mineralCrownWest + mineralCrownEast + centralRockTower + roundedGlacialDomeWest + roundedGlacialDomeEast + broadColWest + broadColCentral + broadColEast + summitSerration + lowerWestValley + lowerEastValley + middleWestValley + middleEastValley + alpineConnector + valleyShoulderWest + valleyShoulderEast + middleSpine + valleyWaves + sideBowlNW + sideBowlSW + sideBowlNE + sideBowlSE + rearBowlWest2 + rearBowlEast2 + localPassW1 + localPassW2 + localPassE1 + localPassE2 + rearPassW + rearPassE + lateralValleyW + lateralValleyE + rearTraverseW + rearTraverseE + buttressW + buttressE + rearButtress + rockBandsWest + rockBandsEast + centralRockBar + westRockBar + rearRockBar + breakLow + breakMid + breakHigh + spurNW + spurNE + spurRearW + spurRearE + geologyCouloirW + geologyCouloirE + microBroad + microDetail + crossRolls + hollowNW + bumpNE + hollowSE + bumpSW + rearHollow + rearBump + localBreaks + cliffWest + cliffEast + cliffRearW + cliffRearE + screeWest + screeEast + crestChips + iceFieldWest + iceFieldEast + iceTongueWest + iceTongueEast + iceBreaks + iceFlowLines + moraineWest + moraineEast + glacierRearShelf + rearDrop + rearBowl + rearFamily + rearSpur + rearRolls);
        }

        public float SlopeDegrees(float x,float z)
        {
            const float d=7f; float xa=Mathf.Max(MinX,x-d), xb=Mathf.Min(-MinX,x+d);
            float za=Mathf.Max(MinZ,z-d), zb=Mathf.Min(MinZ+Length,z+d);
            float dx=(Height(xb,z)-Height(xa,z))/Mathf.Max(.01f,xb-xa), dz=(Height(x,zb)-Height(x,za))/Mathf.Max(.01f,zb-za);
            return Mathf.Atan(Mathf.Sqrt(dx*dx+dz*dz))*Mathf.Rad2Deg;
        }
        public static int SlopeBand(float d) { return d<10f?0:d<18f?1:d<28f?2:3; }
        static float Blend(float x,float a,float b){float t=Mathf.Clamp01((x-a)/(b-a));return t*t*(3f-2f*t);}
        static float Gaussian(float x,float centre,float sigma){float q=(x-centre)/Mathf.Max(1f,sigma);return Mathf.Exp(-.5f*q*q);}
    }
}
